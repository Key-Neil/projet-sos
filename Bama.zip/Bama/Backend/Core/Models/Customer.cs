namespace Core.Models;


public class Customer
{
    public int CustomerId { get; set; }
    public required string Username { get; set; }
}
